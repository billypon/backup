//
//  SWBSmallCloseButtonHighlightView.h
//  SWBuaWeb
//
//  Created by clowwindy on 11-6-10.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SWBSmallCloseButtonHighlightView : UIView {
    
}

@end
