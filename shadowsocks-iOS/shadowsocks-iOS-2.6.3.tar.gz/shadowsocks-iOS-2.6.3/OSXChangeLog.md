1.0.5
------
- Update PAC file
- Add code sign

1.0.4
------
- Fix system proxy settings cleared when exiting with pac turned off

1.0.3
------
- Fix 100% CPU problem when using table encryption.
- Fix "Please fill in the blank" message prompted when public server is selected.

1.0.2
------
- Authorize only once.

1.0.1
------
- Fix image uploading.

1.0
------
- Initial version.

